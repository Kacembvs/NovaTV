# NOVA IPTV — Phase 1 (socle initial)

Ce dépôt contient :
- le cahier des charges complet ;
- un projet Android Kotlin/Compose de départ ;
- un premier écran d’accueil sombre NOVA, avec manifeste compatible lancement mobile et Android TV.

## Ouvrir le projet
1. Décompresser l’archive.
2. Ouvrir le dossier `NOVA_IPTV_Phase1` dans Android Studio.
3. Utiliser JDK 17.
4. Laisser Gradle synchroniser les dépendances, puis lancer `app`.

## État honnête
Cette livraison est un **squelette de Phase 1**, pas l’application complète. Le socle de navigation et l’écran d’accueil sont amorcés. Les tuiles TV/Films/Séries sont uniquement visuelles et explicitement signalées comme telles ; les sources IPTV, le lecteur, Room, l’EPG et les fonctions d’épisodes ne sont pas encore implémentés.

La compilation n’a pas été exécutée dans cet environnement : elle doit être vérifiée dans Android Studio avec le SDK Android installé. Les versions de plugins et dépendances sont des bases de départ à valider lors de la synchronisation Gradle.
